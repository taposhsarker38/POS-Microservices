// features/settings/api.ts
import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

export interface CompanySettings {
  id: string;
  name: string;
  primary_color: string;
  secondary_color: string;
  accent_color: string;
  background_color: string;
  text_color: string;
  logo_url?: string;
  favicon_url?: string;
  created_at: string;
  updated_at: string;
}

export const settingsApi = createApi({
  reducerPath: 'settingsApi',
  baseQuery: fetchBaseQuery({
    baseUrl: `${process.env.NEXT_PUBLIC_API_URL}/api/company/`,
    credentials: 'include',
  }),
  tagTypes: ['CompanySettings'],
  endpoints: (builder) => ({
    getCompanySettings: builder.query<CompanySettings, string>({
      query: (companyId) => `${companyId}/settings/`,
      providesTags: ['CompanySettings'],
    }),
    
    updateCompanySettings: builder.mutation<
      CompanySettings, 
      { companyId: string; settings: Partial<CompanySettings> }
    >({
      query: ({ companyId, settings }) => ({
        url: `${companyId}/settings/`,
        method: 'PATCH',
        body: settings,
      }),
      invalidatesTags: ['CompanySettings'],
    }),
    
    uploadCompanyLogo: builder.mutation<{ logo_url: string }, { companyId: string; formData: FormData }>({
      query: ({ companyId, formData }) => ({
        url: `${companyId}/upload-logo/`,
        method: 'POST',
        body: formData,
      }),
      invalidatesTags: ['CompanySettings'],
    }),
  }),
});

export const { 
  useGetCompanySettingsQuery, 
  useUpdateCompanySettingsMutation,
  useUploadCompanyLogoMutation,
} = settingsApi;